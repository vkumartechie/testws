package com.jpmc.trading.reportengine.dto;

public enum Currency {
	HKD, EUR, JPY, GBP, AUD, CAD, CHF, CNY, SEK, MXN, NZD, SGD, AED, SAR, INR
}
