package com.jpmc.trading.reportengine.dto;

public enum TradeType {
	BUY, SELL
}
